# WellnessCity
A GADS Community Project to help user stay healthy, get Health and Diet tips/advice and Covid 19 Regular Reminder to stay safe
